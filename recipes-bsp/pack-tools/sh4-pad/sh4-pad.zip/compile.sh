#!/bin/bash

if [  -e pad ]; then
  rm pad
fi

g++ -o pad pad.c
